"""
/*****************************************************************************
 * Copyright (c) 2019, Palo Alto Networks. All rights reserved.              *
 *                                                                           *
 * This Software is the property of Palo Alto Networks. The Software and all *
 * accompanying documentation are copyrighted.                               *
 *****************************************************************************/

Copyright 2019 Palo Alto Networks

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.


jharris@paloaltonetworks.com

"""

import logging
import ssl
import urllib
import urllib3
import boto3
import requests
import json




urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


logger = logging.getLogger()
logger.setLevel(logging.INFO)

lambda_client = boto3.client('lambda')
ec2_client = boto3.client('ec2')

def add_alert_all_url_filter_profile(hostname, api_key, profile_name):
    """
    Adds alert all url filter profile
    """
    xpath = "/config/devices/entry[@name='localhost.localdomain']/vsys/entry[@name='vsys1']/" \
            "profiles/url-filtering/entry[@name='{0}']/alert".format(profile_name)
    element = "<member>abortion</member><member>abused-drugs</member>" \
              "<member>adult</member><member>alcohol-and-tobacco</member>" \
              "<member>auctions</member><member>business-and-economy</member>" \
              "<member>command-and-control</member><member>computer-and-internet-info</member>" \
              "<member>content-delivery-networks</member><member>copyright-infringement</member>" \
              "<member>dating</member><member>dynamic-dns</member>" \
              "<member>educational-institutions</member>" \
              "<member>entertainment-and-arts</member><member>extremism</member>" \
              "<member>financial-services</member><member>gambling</member><member>games</member>" \
              "<member>government</member><member>hacking</member><member>health-and-medicine</member>" \
              "<member>home-and-garden</member><member>hunting-and-fishing</member>" \
              "<member>insufficient-content</member><member>internet-communications-and-telephony</member>" \
              "<member>internet-portals</member><member>job-search</member>" \
              "<member>legal</member><member>malware</member><member>military</member>" \
              "<member>motor-vehicles</member><member>music</member><member>news</member>" \
              "<member>not-resolved</member><member>nudity</member><member>online-storage-and-backup</member>" \
              "<member>parked</member><member>peer-to-peer</member><member>personal-sites-and-blogs</member>" \
              "<member>philosophy-and-political-advocacy</member>" \
              "<member>phishing</member><member>private-ip-addresses</member>" \
              "<member>proxy-avoidance-and-anonymizers</member><member>questionable</member>" \
              "<member>real-estate</member><member>recreation-and-hobbies</member>" \
              "<member>reference-and-research</member><member>religion</member>" \
              "<member>search-engines</member><member>sex-education</member>" \
              "<member>shareware-and-freeware</member><member>shopping</member>" \
              "<member>social-networking</member><member>society</member>" \
              "<member>sports</member><member>stock-advice-and-tools</member>" \
              "<member>streaming-media</member><member>swimsuits-and-intimate-apparel</member>" \
              "<member>training-and-tools</member><member>translation</member><member>travel</member>" \
              "<member>unknown</member><member>weapons</member><member>web-advertisements</member>" \
              "<member>web-based-email</member><member>web-hosting</member>"
    return panSetConfig(hostname, api_key, xpath, element)

def log_all_security_policy(hostname, api_key, sec_rulesbase_name, group_profile):
    xpath = "/config/devices/entry[@name='localhost.localdomain']" \
             "/vsys/entry[@name='vsys1']/rulebase/security/rules/entry[@name='{0}']".format(sec_rulesbase_name)

    element = "<to><member>any</member></to><from><member>any</member></from>" \
              "<source><member>any</member></source>" \
              "<destination><member>any</member></destination>" \
              "<application><member>any</member></application>" \
              "<service><member>any</member></service>" \
              "<profile-setting><group><member>{0}</member>" \
              "</group></profile-setting>".format(group_profile)

    return panSetConfig(hostname, api_key, xpath, element)

def add_profile_to_grp_profile(hostname, api_key, profile, group_profile):
    """
    Adds a security profile to a group profile
    """
    xpath = "/config/devices/entry[@name='localhost.localdomain']" \
            "/vsys/entry[@name='vsys1']/profile-group/entry[@name='{0}']/url-filtering".format(group_profile)
    element = "<member>{0}</member>".format(profile)
    return panSetConfig(hostname, api_key, xpath, element)

def add_grp_profile_to_policy(hostname, api_key, rulebase_policy, group_profile):
    """
    Adds existing security group profile to existing security rulebase policy
    """""
    xpath = "/config/devices/entry[@name='localhost.localdomain']" \
             "/vsys/entry[@name='vsys1']/rulebase/security/rules/entry[@name='{0}']/profile-setting/group".format(rulebase_policy)
    element = "<member>{0}</member>".format(group_profile)

    return panSetConfig(hostname, api_key, xpath, element)

def panSetConfig(hostname, api_key, xpath, element):
    """Function to make API call to "set" a specific configuration
    """
    data = {
        'type': 'config',
        'action': 'set',
        'key': api_key,
        'xpath': xpath,
        'element': element
    }
    logger.info("Updating set config with xpath \n{} and element \n{} ".format(xpath, element))
    response = makeApiCall(hostname, data)
    # process response and return success or failure?
    return response

def makeApiCall(hostname, data):
    """
    Makes the API call to the firewall interface.  We turn off certificate checking before making the API call.
    Returns the API response from the firewall.
    :param hostname:
    :param data:
    :return: Expected response
    <response status="success">
        <result>
            <![CDATA[yes\n]]>
        </result>
    </response>
    """
    url = "https://" + hostname + "/api"
    response = requests.post(url, data=data, verify=False,)
    if response.text.find('success'):
        return True
    else:
        return False



def lambda_handler(event, context):
    '''
    event ={
        fw_mgt_ip : 'x.x.x.x'
        api_key : 'xxxxxxxxxxxxxxxxx
        }
    :return event
        event ={
            fw_mgt_ip : 'x.x.x.x'
            api_key : 'xxxxxxxxxxxxxxxxx
            Action:'fw_ready'
            }
    '''
    logger.info("Got Event {}".format(event))
    fw_mgt_ip = event['fw_mgt_ip']
    api_key = event['api_key']

    # Constants for policy names
    rulebase_policy = 'log-all'
    group_profile = 'slr-log-all'
    url_filter_profile = 'Alert-Only-URL'

    add_alert_all_url_filter_profile(fw_mgt_ip, api_key, url_filter_profile)
    add_profile_to_grp_profile(fw_mgt_ip, api_key, url_filter_profile, group_profile)
    if add_grp_profile_to_policy(fw_mgt_ip, api_key, rulebase_policy, group_profile):
        event.update({'Action': 'fw_policy_updated'})

    event.update({'Action':'fw_ready'})
    logger.info('Firewall is ready')

    return event





if __name__ == '__main__':
    event = {'fw_mgt_ip': '63.35.4.102',
             'api_key': 'LUFRPT1pcktLR3o2OUxwVnFUa01MdDgyUVF4aXlzZXM9QzRyUDdCWTJTWHZSaDIyaHk5czEvdGZ5eUN5SFROSWNZME9FTlB2OHBQNjFja3NWMzdXQVB2UVBzL1AwOUlzKw==',
             'Action': 'fw_ready'}

    context = ''
    lambda_handler(event, context)







