<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<h2>Welcome to Palo Alto Cloud SLR!</h2>

<form name="refresh" action="vpc.php" method="POST">
<input type="submit" name="vpc" value="Explore VPC"/>

</form>
